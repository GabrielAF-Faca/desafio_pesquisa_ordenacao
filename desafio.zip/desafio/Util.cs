﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio
{
    internal class Util
    {
        /// <summary>
        /// Método de ordenação Shake (agitação)
        /// </summary>
        /// <param name="lista">Lista de Aluno</param>
        public static void shake_sort(List<Aluno> lista)
        {
            int ini = 0, fim = lista.Count - 1;
            bool houveTroca = false;


            string nome1 = "alex";
            string nome2 = "peter";

            
            String.Compare(nome1, nome2, true);
            

            /*
            do
            {

                houveTroca = false;

                for (int i = ini; i < fim; i++)
                {
                    if (lista[i] > lista[i + 1])
                    {

                        int aux = lista[i];
                        lista[i] = lista[i + 1];
                        lista[i + 1] = aux;
                        houveTroca = true;

                    }

                }

                if (!houveTroca) break;

                fim--;

                houveTroca = false;

                for (int i = fim; i > ini; i--)
                {
                    if (lista[i] < lista[i - 1])
                    {

                        int aux = lista[i];
                        lista[i] = lista[i - 1];
                        lista[i - 1] = aux;
                        houveTroca = true;

                    }

                }

                ini++;

            } while (houveTroca && ini <= fim);
            */
        }

    }
}
